var numero1 = 0;
var numero2 = 0;
var operatore = '';

$('.btn-number').click(function () {
    var cifra = $(this).data('number');
    var numero = $('#area').val(); // Perchè no attr('value')

    numero = parseInt(numero + cifra);

    $('#area').val(numero);
});

$('.btn-operator').click(function () {
    operatore = $(this).data('operator');
    var numero = $('#area').val();

    numero1 = parseInt(numero);

    $('#area').val('');

    console.log(numero1);
    console.log(operatore);
});

$('.btn-equal').click(function () {
    var numero = $('#area').val();

    numero2 = parseInt(numero);

    var risultato = calcolatrice(numero1, numero2, operatore);

    $('#area').val(risultato);
});

function calcolatrice(numero1, numero2, operatore) {

    console.log(numero1);
    console.log(numero2);
    console.log(operatore);


    switch (operatore) {
        case '+':
            return numero1 + numero2;

        case '-':
            return numero1 - numero2;

        case '*':
            return numero1 * numero2;

        case '/':
            return numero1 / numero2;
    }
}
$('.btn-number').click(function () {
    var cifra = $(this).data('number');
    var operazione = $('#area').val(); // Perchè no attr('value')

    operazione = operazione + cifra;

    $('#area').val(operazione);
});

$('.btn-equal').click(function () {
    var operazione = $('#area').val();

    var risultato = eval(operazione);

    $('#area').val(risultato);
});